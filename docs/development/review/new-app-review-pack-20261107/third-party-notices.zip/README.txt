Pourlune third-party notices extracted from iOS 0.5.0 (22).
These notices document bundled material, not an assertion that this internal TestFlight build is ready for App Store review. No private SDK source or media binaries are included. Recheck against the intended final submission build.
